const express = require("express")
const db = require("./sql")
const cors = require("cors")
const app = express()
app.use(cors())
app.use(express.json())
const bcrypt=require('bcrypt')
const saltrounds=10
const jwt = require("jsonwebtoken")


const JWT_SECRET = "mycode"
function generatetokens(userId,role) {
    return jwt.sign({id: userId, role }, JWT_SECRET, { expiresIn: "1h" })
}


const verifyToken = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json({ error: "Unauthorized, no token provided" });
  }

  const token = authHeader.split(" ")[1];
  if (!token) {
    return res.status(401).json({ error: "Unauthorized, token missing" });
  }

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      console.log("JWT Error:", err);
      return res.status(403).json({ error: "Invalid token" });
    }
    req.user = decoded;
    next();
  });
};


app.post('/login', (req, res) => {
    const { emailid, password } = req.body
    const sql = 'select * from user where emailid=?'
    db.query(sql, [emailid], async (err, result) => {
        if (err) return res.status(500).json({ message: "database issue" })
        if (result.length == 0) return res.status(400).json({ message: "user not found" })
        else {
            // console.log(result)
            const user = result[0]
            const checkpwd = await bcrypt.compare(password, user.password)
            //  console.log(checkpwd)
            if (!checkpwd) return res.status(400).json({ message: "incorrect password" })


            let token = generatetokens(user.userid, user.role)
            console.log(user.userid)
            console.log(user.role)
            res.status(200).json({ token, role: user.role })
        }
    })
})


app.post('/userRegister', (req, res) => {
    const { firstname, city, emailid,  password , mobile} = req.body
    const existingUser = "select * from user where  emailid=?"

    // findexisting user
    db.query(existingUser, [emailid], async (err, result) => {
        if (result.length > 0) {
            return res.status(400).json({ message: "User Already Exist" })
        }
        else {
            const sqlQuery = "INSERT INTO user ( username, city, emailid, password, mobile) VALUES ( ?, ?, ?, ?,?)";

            bcrypt.hash(password, saltrounds, (err, hash) => {
                if (err) {
                  
                    return res.status(500).json({ message: "Hashing Error" });
                }

                db.query(sqlQuery, [firstname, city, emailid, hash, mobile], (err) => {
                    if (err) {
                      
                        return res.status(500).json({ message: "Database Error" });
                    }
                    return res.status(200).json({ message: " User Registered Successfully" });
                });
            });
        }
    })
})

app.post('/post/tasks',verifyToken, (req, res) => {
    // console.log("Authorization header:", req.headers.authorization); 
    //  console.log("req.user:", req.user); 
    // console.log(req.body)
    let { title, des } = req.body
     const userId = req.user.id; 
   
    db.query('insert into details(title, description, startdate, status,userid) values(?,?,curdate(),0,?)', [title, des,userId], (err) => {
        if (err) {
          
             return res.status(500).json({ error: "Database error" });
        } else {
            res.json({ message: "Task inserted" });
        }
    })
})

app.get('/get/tasks',verifyToken, (req, res) => {
  const userId = req.user.id;
    const sqlquery = "select id,title,description,date_format(startdate, '%y-%m-%d' ) as startdate, date_format(enddate, '%y-%m-%d' ) as enddate, timestampdiff(day,startdate, enddate) as duration, status from details where userid=?"

    db.query(sqlquery,[userId], (error, result)=>{
        if (error){
 console.log("Error Fetching Data")
             return res.status(500).json([]);
        }
            else{
                res.json(result || [])
            }
            
    })
})

app.delete('/delete/tasks/:id',verifyToken, (req, res) => {
    console.log(req.body)
    const { id } = req.params
    let userid = Number(id)
    db.query('delete from details where id=?', [userid], (err) => {
        if (err) {
          
        }
        else {
            res.json({ message: "deleted" })
        }
    })
})


app.put('/put/tasks/:id',verifyToken, (req, res) => {
    const id = req.params.id;
    console.log(id)
    
    const { title, description } = req.body;

    const query = 'UPDATE details SET title = ?, description = ? WHERE id = ?';
    db.query(query, [title, description, id], (err, result) => {
        if (err) {
            res.status(500).send(err);
        } else {
            res.json({ message: 'User updated successfully' });
        }
    });
});


app.put('/usercomplete/:id',verifyToken, (req, res) => {
    const id = req.params.id;
    console.log(id)
    const status=1

    const query = 'UPDATE details SET status = ?,enddate=now()  WHERE id = ?';
    db.query(query, [status, id], (err, result) => {
        if (err) {
            res.status(500).send(err);
        } else {
            res.json({ message: 'task completed' });
        }
    });
});



app.listen(5050, (err) => err ? console.log(err) : console.log("success"))