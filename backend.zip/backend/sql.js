const sql=require("mysql2")
const db=sql.createConnection({
    host:"localhost",
    user:"root",
    password:"root123",
    database:"node1"
})
db.connect((err)=>err?console.log(err):console.log("connected"))
module.exports=db;