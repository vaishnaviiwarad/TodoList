import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";


function UserLogin({ updaterole }) {
  const navigate = useNavigate();
  const [formdata, setFormdata] = useState({ emailid: "", password: "" });

  const dataHandler = (e) => {
    const { name, value } = e.target;
    setFormdata((existing) => ({
      ...existing,
      [name]: value,
    }));
  };

  const submitHandler = async (e) => {
    e.preventDefault();
    let response = await fetch("http://localhost:5050/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formdata),
    });
    const result = await response.json();

    if (response.status === 200) {
      localStorage.setItem("token", result.token);
      localStorage.setItem("role", result.role);
      updaterole(result.role);
      navigate("/addtasks");
    } else {
      alert("Login failed");
    }
  };

  return (
    <div
      className="d-flex justify-content-center align-items-center min-vh-100"
      style={{
        background: "linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)",
      }}
    >
      <div
        className="card p-5 shadow-lg"
        style={{
          width: "100%",
          maxWidth: "400px",
          borderRadius: "20px",
          backdropFilter: "blur(10px)",
          backgroundColor: "rgba(255,255,255,0.15)",
          color: "#fff",
        }}
      >
        <h2 className="text-center mb-4 fw-bold">User Login</h2>
        <form onSubmit={submitHandler}>
          <div className="mb-3">
            <input
              type="text"
              className="form-control bg-transparent text-white border-light"
              name="emailid"
              placeholder="Email ID"
              value={formdata.emailid}
              onChange={dataHandler}
              required
            />
          </div>

          <div className="mb-3">
            <input
              type="password"
              className="form-control bg-transparent text-white border-light"
              name="password"
              placeholder="Password"
              value={formdata.password}
              onChange={dataHandler}
              required
            />
          </div>

          <div className="mb-3 d-flex justify-content-center">
            <button
              type="submit"
              className="btn w-50 fw-semibold text-white"
              style={{
                background: "linear-gradient(90deg, #ff9966, #ff5e62)",
                border: "none",
                borderRadius: "10px",
                height: "45px",
              }}
            >
              Login
            </button>
          </div>

         
        </form>
      </div>
    </div>
  );
}

export default UserLogin;
