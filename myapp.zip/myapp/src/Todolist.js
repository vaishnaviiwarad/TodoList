import React, { useEffect, useState } from "react";

function Todolist() {
  const [fetchlist, setfetchList] = useState([]);
  const [targetData, setTargetData] = useState(null);
  const [updateData, setUpdateData] = useState({ title: "", description: "" });
  const [filter, setFilter] = useState("all"); 
  const token = localStorage.getItem("token");

  async function fetchHandler() {
    let response = await fetch("http://localhost:5050/get/tasks", {
      headers: { Authorization: `Bearer ${token}` },
    });
    let data = await response.json();
    setfetchList(data);
  }

  useEffect(() => {
    fetchHandler();
  }, []);

  async function deleteuser(id) {
    let response = await fetch(`http://localhost:5050/delete/tasks/${id}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    });
    let result = await response.json();
    console.log(result);
    alert(result.message);
    fetchHandler();
  }

  let updateHandler = (data) => {
    setTargetData(data.id);
    setUpdateData({ title: data.title, description: data.description });
  };

  let dataHandler = (e) => {
    let { name, value } = e.target;
    setUpdateData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  let saveHandler = async (id) => {
    const response = await fetch(`http://localhost:5050/put/tasks/${id}`, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(updateData),
    });
    let result = await response.json();
    alert(result.message);
    fetchHandler();
    setTargetData(null);
  };

  let completeHandler = async (id) => {
    const response = await fetch(`http://localhost:5050/usercomplete/${id}`, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    });
    let result = await response.json();
    alert(result.message);
    fetchHandler();
    setTargetData(null);
  };

  let cancelHandler = () => {
    setTargetData(null);
  };

  const filteredList = fetchlist.filter((data) => {
    if (filter === "pending") return Number(data.status) === 0;
    if (filter === "completed") return Number(data.status) === 1;
    return true; // all
  });

  return (
    <div
      className="min-vh-100 py-4"
      style={{
        background: "linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)",
        color: "white",
      }}
    >
      <div className="container">
        <h1 className="text-center mb-4 fw-bold">
          TaskList
        </h1>

        <div className="text-center mb-3">
          <button
            className={`btn btn-light mx-2 ${filter === "all" ? "active" : ""}`}
            onClick={() => setFilter("all")}
          >
            All
          </button>
          <button
            className={`btn btn-warning mx-2 ${
              filter === "pending" ? "active" : ""
            }`}
            onClick={() => setFilter("pending")}
          >
            Pending
          </button>
          <button
            className={`btn btn-success mx-2 ${
              filter === "completed" ? "active" : ""
            }`}
            onClick={() => setFilter("completed")}
          >
            Completed
          </button>
        </div>

        <div className="table-responsive shadow-lg rounded">
          <table className="table table-hover align-middle text-center table-bordered bg-white">
            <thead className="table-primary">
              <tr>
                <th>ID</th>
                <th>TITLE</th>
                <th>DESCRIPTION</th>
                <th>START DATE</th>
                <th>END DATE</th>
                <th>STATUS</th>
                <th>DELETE</th>
                <th>UPDATE</th>
                <th>COMPLETED</th>
                <th>DURATION</th>
              </tr>
            </thead>
            <tbody>
              {filteredList.length === 0 ? (
                <tr>
                  <td colSpan="10" className="text-muted">
                    No tasks found 
                  </td>
                </tr>
              ) : (
                filteredList.map((data) => (
                  <tr key={data.id}>
                    <td>{data.id}</td>
                    <td>
                      {targetData === data.id ? (
                        <input
                          type="text"
                          name="title"
                          value={updateData.title}
                          onChange={dataHandler}
                          className="form-control"
                        />
                      ) : (
                        data.title
                      )}
                    </td>
                    <td>
                      {targetData === data.id ? (
                        <input
                          type="text"
                          name="description"
                          value={updateData.description}
                          onChange={dataHandler}
                          className="form-control"
                        />
                      ) : (
                        data.description
                      )}
                    </td>
                    <td>{data.startdate}</td>
                    <td>{data.enddate}</td>
                    <td>
                      {data.status == 0 ? (
                        <span className="badge bg-warning text-dark">
                          Pending
                        </span>
                      ) : (
                        <span className="badge bg-success">Completed</span>
                      )}
                    </td>
                    <td>
                      <button
                        className="btn btn-danger btn-sm"
                        onClick={() => deleteuser(data.id)}
                        disabled={data.status == 1}
                      >
                        Delete
                      </button>
                    </td>
                    <td>
                      {targetData === data.id ? (
                        <>
                          <button
                            className="btn btn-success btn-sm me-2"
                            onClick={() => saveHandler(data.id)}
                                
                          >
                            Save
                          </button>
                          <button
                            className="btn btn-secondary btn-sm"
                            onClick={cancelHandler}
                          >
                            Cancel
                          </button>
                        </>
                      ) : (
                        <button
                          className="btn btn-primary btn-sm"
                          onClick={() => updateHandler(data)}
                          disabled={data.status == 1}
                        >
                          Update
                        </button>
                      )}
                    </td>
                    <td>
                      <button
                        className="btn btn-info btn-sm"
                        onClick={() => completeHandler(data.id)}
                        disabled={data.status == 1}
                      >
                        Mark Done
                      </button>
                    </td>
                    <td>{data.duration} days</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default Todolist;
