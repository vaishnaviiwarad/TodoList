import React, { useState } from "react";

function AddTasks() {
  const [title, setTitle] = useState("");
  const [des, setDes] = useState("");

  async function formHandler(e) {
    e.preventDefault();
     const token = localStorage.getItem("token"); 
    let response = await fetch("http://localhost:5050/post/tasks", {
      method: "POST",
      headers: { "Authorization": `Bearer ${token}`,
      "Content-Type": "application/json" },
      body: JSON.stringify({ title, des }),
    });
    let result=await response.json();
    console.log(result);
    alert("task added")
    setDes("");
    setTitle("");
  }

  return (
    <div
      className="d-flex justify-content-center align-items-center min-vh-100"
      style={{
        background: "linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)",
      }}
    >
      <div
        className="card p-4 shadow-lg border-0"
        style={{
          width: "100%",
          maxWidth: "420px",
          backdropFilter: "blur(10px)",
          backgroundColor: "rgba(255,255,255,0.15)",
          borderRadius: "20px",
          color: "#fff",
        }}
      >
        <h2 className="text-center mb-3 fw-bold">Add tasks</h2>
        <p className="text-center text-light mb-4">
          Fill in your details to get started 
        </p>
        <form onSubmit={formHandler}>
          <div className="mb-3">
            <input
              type="text"
              placeholder="Enter Title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="form-control bg-transparent text-white border-light"
              required
            />
          </div>
          <div className="mb-3">
            <input
              type="text"
              placeholder="Enter Description"
              value={des}
              onChange={(e) => setDes(e.target.value)}
              className="form-control bg-transparent text-white border-light"
              required
            />
          </div>
          <button
            className="btn w-100 fw-semibold text-white"
            style={{
              background: "linear-gradient(90deg, #ff9966, #ff5e62)",
              border: "none",
              borderRadius: "10px",
              height: "45px",
            }}
            type="submit"
          >
            Submit
          </button>
        </form>
      </div>
    </div>
  );
}

export default AddTasks;
