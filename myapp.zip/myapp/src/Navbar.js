import React from "react";
import { Link } from "react-router-dom";

function Navbar({role}) {
  return (
    <nav
      className="navbar navbar-expand-lg navbar-dark"
      style={{
        background: "linear-gradient(90deg, #6a11cb 0%, #2575fc 100%)",
      }}
    >
      <div className="container">
        <Link className="navbar-brand fw-bold text-white" to="/">
          MyApp
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">

            {role=="user"?(<>
          
             <li className="nav-item">
              <Link className="nav-link text-white fw-semibold" to="/addtasks">
                Add Tasks
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link text-white fw-semibold" to="/list">
                Todo List
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link text-white fw-semibold" to="/logout">
                Logout
              </Link>
            </li>
            </>):(<>
              <li className="nav-item">
              <Link className="nav-link text-white fw-semibold" to="/register">
                UserRegister
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link text-white fw-semibold" to="/login">
              UserLogin
              </Link>
            </li>
            </>)}
            
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
