import React from "react";

function Home() {
  return (
    <div
      className="d-flex flex-column justify-content-center align-items-center min-vh-100 text-center"
      style={{
        background: "linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)",
        color: "#fff",
        padding: "20px",
      }}
    >
      <h1 className="display-3 fw-bold mb-4">Welcome to My Todo App</h1>
      <p className="lead mb-5" style={{ maxWidth: "600px" }}>
        This is a simple Todo Application to help you organize your tasks, stay
        productive, and manage your time efficiently.
      </p>

      <div className="card p-4 shadow-lg" style={{ maxWidth: "600px", borderRadius: "20px", backgroundColor: "rgba(255,255,255,0.15)" }}>
        <h2 className="fw-bold mb-3">Features</h2>
        <ul className="list-unstyled text-start">
          <li>✅ Add, update, and delete tasks</li>
          <li>✅ Mark tasks as completed</li>
          <li>✅ Track task duration</li>
          <li>✅ Responsive design for all devices</li>
        </ul>
      </div>

      <footer className="mt-5 text-white-50">
        &copy; {new Date().getFullYear()} My Todo App. All rights reserved.
      </footer>
    </div>
  );
}

export default Home;
