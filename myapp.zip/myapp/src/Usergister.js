import React, { useState } from "react";

function Usergister() {
  const [formdata, setFormData] = useState({
    firstname: "",
    city: "",
    emailid: "",
    password: "",
    mobile: "",
  });

  const formDataHandler = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const submitHandler = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch("http://localhost:5050/userRegister", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formdata),
      });

      const result = await response.json();

      if (response.status === 400) {
        alert(result.message);
        return;
      }

      if (response.status === 200) {
        alert(result.message);
        setFormData({
          firstname: "",
          city: "",
          emailid: "",
          password: "",
          mobile: "",
        });
      }
    } catch (error) {
      console.error("Registration failed:", error);
      alert("Something went wrong. Please try again.");
    }
  };

  return (
    <div
      className="d-flex justify-content-center align-items-center min-vh-100"
      style={{
        background: "linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)",
      }}
    >
      <div
        className="card p-4 shadow-lg"
        style={{
          width: "100%",
          maxWidth: "400px",
          borderRadius: "20px",
          backdropFilter: "blur(10px)",
          backgroundColor: "rgba(255,255,255,0.15)",
          color: "#fff",
        }}
      >
        <h2 className="text-center mb-4 fw-bold">User Registration</h2>
        <form onSubmit={submitHandler}>
          <div className="mb-3">
            <input
              type="text"
              name="firstname"
              value={formdata.firstname}
              onChange={formDataHandler}
              className="form-control bg-transparent text-white border-light"
              placeholder="First Name"
              required
            />
          </div>

          <div className="mb-3">
            <input
              type="text"
              name="city"
              value={formdata.city}
              onChange={formDataHandler}
              className="form-control bg-transparent text-white border-light"
              placeholder="City"
              required
            />
          </div>

          <div className="mb-3">
            <input
              type="email"
              name="emailid"
              value={formdata.emailid}
              onChange={formDataHandler}
              className="form-control bg-transparent text-white border-light"
              placeholder="Email ID"
              required
            />
          </div>

          <div className="mb-3">
            <input
              type="password"
              name="password"
              value={formdata.password}
              onChange={formDataHandler}
              className="form-control bg-transparent text-white border-light"
              placeholder="Password"
              required
              pattern=".{6,}"
              title="Password must be at least 6 characters long"
            />
          </div>

          <div className="mb-3">
            <input
              type="text"
              name="mobile"
              value={formdata.mobile}
              onChange={formDataHandler}
              className="form-control bg-transparent text-white border-light"
              placeholder="Mobile"
              required
            />
          </div>

          <button
            type="submit"
            className="btn w-100 fw-semibold text-white"
            style={{
              background: "linear-gradient(90deg, #ff9966, #ff5e62)",
              border: "none",
              borderRadius: "10px",
              height: "45px",
            }}
          >
            Register
          </button>
        </form>
      </div>
    </div>
  );
}

export default Usergister;
