import AddTasks from "./AddTasks";
import Navbar from "./Navbar";
import Todolist from "./Todolist";
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom'
import Usergister from "./Usergister";
import UserLogin from './UserLogin'
import { useState } from "react";
import Logout from "./Logout";
import Home from "./Home";

function App() {

  const [role, setRole] = useState(localStorage.getItem("role"))


  const updaterole = (role) => {
    setRole(role);
    if (role) {
      localStorage.setItem("role", role);
    } else {
      localStorage.removeItem("role");
    }
  };
  return (
    <>
    
    <Router>
    <Navbar role={role}/>
      <Routes>
        <Route path="/" element={<Home/>}></Route>
        <Route path="/addtasks" element={<AddTasks/>}></Route>
        <Route path="/register" element={<Usergister/>}></Route>
        <Route path="/login" element={<UserLogin updaterole={updaterole} />}></Route>
        <Route path="/list" element={<Todolist/>}></Route>
        <Route path="/logout" element={<Logout  updaterole={updaterole}/>}></Route>
      </Routes>
    </Router>
    </>
  );
}

export default App;
